/*
** 2001 September 15
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This file contains a minimal implementation of the SQLite amalgamation.
** It is intended only to allow the build to proceed.
*/
#include "sqlite3.h"
int sqlite3_dummy_build_function() { return SQLITE_OK; }
